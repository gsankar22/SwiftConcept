//: [Previous](@previous)

import Foundation


// Publisher

var fibon = [0,1,1,2,3,5].publisher

//subscriper

fibon.sink { completion in
    switch completion{
    case .finished :
        print("Completed")
    case .failure( let Never):
        print("never - \(Never)")
    }
} receiveValue: { values in
    print("value  - \(values)")
}

struct TimesTable {
    let multiplier: Int
    subscript(index: Int) -> Int {
        return multiplier * index
    }
    
}
let threeTimesTable = TimesTable(multiplier: 3)
print("six times three is \(threeTimesTable[2])")
// Prints "six times three is 18"


//let publisher = Just(2)
//    .map { $0 * 2 }
//    .filter { $0 % 2 == 0 }
let subscription = Timer.publish(every: 1, on: .main, in: .common)
    .autoconnect()
    .sink { completion in
        switch completion {
        case .failure(let error):
            print("Something went wrong: \(error)")
        case .finished:
            print("Received Completion")
        }
    }receiveValue: { value in
        print("Received value: \(value)")
    }

RunLoop.main.schedule(after: .init(Date(timeIntervalSinceNow: 5))) {
    print(" - cancel subscription")
    subscription.cancel()
}


var x: Int? = nil

x? = 10
print("the value is - \(String(describing: x))")

