//: [Previous](@previous)

import Foundation

/* Swift  Deinitialization */
/* freeup the memory space occupied by the system */
/* Deinitializer is the process to deallocate the memory which is no longer needed */

// declare a class
class  DeinitClass {
    var value: Int = 0
    
    // define initializer
    init() {
        value = 5
        print("memory initializer")
        print("Total value:", value)
    }
    // define deinitializer
    deinit {
        print("Memory Deallocated")
    }
}

extension DeinitClass {
    func lapcount(newvalue: Int) -> Int {
        return newvalue + value
    }
}

// create an instance As optional
var result: DeinitClass? = DeinitClass()
print("Valuse :\(result?.lapcount(newvalue: 20) ?? 10)")
// deallocate object
result = nil
