
/*
 //Learning From
 https://www.youtube.com/watch?v=CwA1VWP0Ldw&list=PL8seg1JPkqgHtditjG_y2DuYuj9FJommY
 https://www.youtube.com/watch?v=HXoVSbwWUIk
 https://www.youtube.com/watch?v=b1oC7sLIgpI
 
 //Solid Principe
 https://medium.com/@nishant.kumbhare4/solid-principles-in-swift-73b505d3c63f
 https://www.programiz.com/swift-programming/initializer
 
 //Online App
 https://www.youtube.com/watch?v=YHrJQGKWJHE&list=PLzcRC7PA0xWSuwiPqTEhLLMncu0kVWnyU&index=1
 https://github.com/codeforany?tab=repositories
 https://www.youtube.com/watch?v=n5X_V81OYnQ
 */



import SwiftUI
import UIKit
import Combine



protocol testsample {
    var name:String { get }
    var age: Int { get }
}



class sampletest:testsample {
    var name: String
    var age: Int
    
    init(name: String, age: Int) {
        self.age = age
        self.name = name
    }
    
    func sample1() -> Void {
        print("the user \(name) and the age is \(age)")
    }
}

var class_obj1 = sampletest(name: "Test", age: 32)
class_obj1.sample1()




protocol carNeed{
    
    var carName: String {set get}
    var carmanufactureYear: Int { get }
    var carModel: String? { get }
    
    func carInterior()
    
    
}

extension carNeed{
    var carPrice: Int {
        carPrice
    }
    func carExterior(){}
}


class car: carNeed {
    
    var carModel: String?
    
    var carName: String
    
    var carmanufactureYear: Int
    
    func carInterior() {
        print("Car name:\(carName) and Year: \(carmanufactureYear) and CarPrice: \(carPrice)")
    }
    
    var color:String
    
    init(color: String, carName: String, carmanufactureYear: Int ) {
        self.color = color
        self.carName = carName
        self.carmanufactureYear = carmanufactureYear
    }
}

var mycar1 = car(color: "Orange", carName: "Ford Figo", carmanufactureYear: 2011)
//var mycar2 = mycar1
//mycar2.color = "blue"

print("car1,\(mycar1.color)")
//print("car2,\(mycar2.color)")

mycar1.carName = "polo"
mycar1.carInterior()
//mycar1.carPrice = 100000


let mapexample = [1,2,3,4,5]
let myMap = mapexample.map{ $0}
print("Mymap",myMap)



