//: [Previous](@previous)

import Foundation

/* Swift Equatable */
/* Equatable is the protocal allows two object to compair using == operator */
struct Employ: Equatable {
    var name: String
}

let obj1 = Employ(name: "Sabby")
let obj2 = Employ(name: "Smith")

// compare obj1 and obj2
if obj1 == obj2 {
    print("obj1 and obj2 are equal")
}
else {
    print("obj1 and obj2 are not equal")
}

/* Equatable Function */
func == (lhs: Employ, rhs: Employ) -> Bool {
    return lhs.name == rhs.name
}

