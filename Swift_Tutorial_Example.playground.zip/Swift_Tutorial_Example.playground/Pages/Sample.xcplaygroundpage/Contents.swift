//: [Previous](@previous)

import Foundation

@propertyWrapper
struct trimmed {
    var name: String
    private (set) var wrappedValue:String {
        get{
            name.trimmingCharacters(in: .whitespacesAndNewlines)
        }
        set{
            name = newValue
            
        }
    }
}

struct mycalss {
    @trimmed var userName: String
}

let obj1 = mycalss(userName: trimmed(name: "          GowriSankar         "))
print(obj1.userName)



//closure

var studentData: ((Int) -> Bool) = { markNum in
    if markNum > 35{
        return true
    } else {
        return false
    }
}

studentData(30)

func studentStatus(markNumber: Int)->Bool{
    
    if markNumber > 35{
        return true
    } else {
        return false
    }
}

studentStatus(markNumber: 40)
