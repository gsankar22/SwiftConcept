//: [Previous](@previous)

import Foundation

/**  kvc and KVO Example */

class Person1: NSObject {
    @objc dynamic var name: String
    @objc dynamic var age: Int
    
    init(name: String, age: Int) {
        self.name = name
        self.age = age
    }
}


let person1 = Person1(name: "John Doe", age: 30)

// Using KVC to get the value
let personName = person1.value(forKey: "name") as? String
print("Person's name: \(personName ?? "")")

// Using KVC to set the value
person1.setValue("Jane Doe", forKey: "name")
print("Updated name: \(person1.name)")


class Observer: NSObject {
    var observation: NSKeyValueObservation?
    
    func startObserving(person: Person1) {
        observation = person.observe(\.name, options: [.new]) { (_, change) in
            if let newName = change.newValue {
                print("Person's name changed to \(newName)")
            }
        }
    }
}

let person2 = Person1(name: "John Doe", age: 30)
let observer = Observer()
observer.startObserving(person: person2)

// Triggering a change to see the observation in action
person2.name = "Jane Doe"


