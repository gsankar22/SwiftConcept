//: [Previous](@previous)

import Foundation


/* Static property and function does not required instance access directly */
/* Static method  cannot inheritance or override  */

class Employee {
    
    var name: String
    static var desgination: String = " "
    class var mycountry : String {
        return "India"
    }
    
    init(Sname:String){
        self.name = Sname
    }
    
    static func staticFunction(name : String) {
        print("staticFunction: \(name) Designation: \(desgination)" )
    }
    
    class func classFunction(value : String){
        print("classFunction: \(value) and country: \(mycountry)")
    }
    
    func normalFunction(){
        print("NormalFunction: Hello \(name)")
    }
    
}





let emplotee_obj = Employee(Sname: "gowrisankar")


//required object to call normal function
emplotee_obj.normalFunction()

//Static property object not required
Employee.desgination = "Technical Manager"

//Static function object not required
Employee.staticFunction(name: "Gowrisankar Samy")

/*  ----------------------------------------------------------------- */


/* Static method  cannot inheritance or override  */

protocol Employee11 {
    func getSlary()
    static func getpayDate()
}


class salery:Employee11{
    func getSlary() {
        print("getSlary")
    }
    
    static func getpayDate() {
        print("getpayDate")
    }
}

class Employ : salery {
    override func getSlary() {
        print("Override the class function")
    }
    //Cannot override the static method
    /* override static func getpayDate(){
     print("Static functiom")
     } */
}

let emp = Employ()
emp.getSlary()
//emp.getpayDate() // Static method cannot use the instanse
Employ.getpayDate()



