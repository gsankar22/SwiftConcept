//: [Previous](@previous)

import Foundation

/* Class property and function does not required instance access directly */
/* Class Stored Properties not supported in classes */

class Employee {
    /* //Class Stored Properties not supported in classes
     class let mycountry = "india" */
    
    var name: String = ""
    class var myPosition : String {
        return "technical manager"
    }
    class func classFunction(value : String) {
        print("classFunction: \(value) and Job: \(myPosition)")
    }
}

//class computed property
debugPrint("Print  class property: \(Employee.myPosition)")

//class function object not required
Employee.classFunction(value: "Gowrisankar Samy")








