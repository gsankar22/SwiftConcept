//: [Previous](@previous)

import Foundation

/* Stored property */
/* stored property is a constant or variable that is stored as part of an instance of a particular class or structure. */
/* Stored properties can also have default values */
/* Stored properties can also be defined in struct and enum */

struct Stored {
    
    var storedName : String = "Storedproperty"
    
    static var age : Int {
        return 26
    }
    
    init(name: String){
        self.storedName = name
    }
    
}

Stored.init(name: "Sankar")
Stored.age
//print("Name is \(")
print("Age is \(Stored.age)")
