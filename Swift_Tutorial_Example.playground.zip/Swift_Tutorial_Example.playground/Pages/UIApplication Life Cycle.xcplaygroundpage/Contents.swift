//: [Previous](@previous)

import Foundation



/* There are 5 types of application states */
/*
 1) Launching the App (Not Running)
 2) foreground Inactive
 3) Fourground Active
 4) Background
 5) Suspended / Terminating
 */

