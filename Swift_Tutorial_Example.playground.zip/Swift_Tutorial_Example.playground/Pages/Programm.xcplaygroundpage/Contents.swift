//: [Previous](@previous)

import Foundation

/* ----------------------------- prime Number  ------------------------ */
func isPrime(_ number: Int) -> Bool {
    guard number >= 2 else { return false }
    
    for i in 2..<number {
        if number % i == 0 {
            return false
        }
    }
    return true
}

// Test the function
print(isPrime(7))  // Output: true
print(isPrime(10)) // Output: false

/* ------------------------- fibonacciSeries ------------------------------------*/
func fibonacciSequence (i: Int) -> [Int]  {
    
    // Consumes a number "n", which is the number of iterations to go through with the Fibonacci formula and prints such sequence.
    
    var fibonacciArray = [Int]()
    
    for i in 0 ... i {
        
        if i == 0 {
            fibonacciArray.append(0)
        }
        else if i == 1 {
            fibonacciArray.append(1)
        }
        else {
            fibonacciArray.append (fibonacciArray[i-1] + fibonacciArray[i-2] )
        }
    }
    return fibonacciArray
}


fibonacciSequence(i: 5)
print(fibonacciSequence(i: 5)) // Output: [0, 1, 1, 2, 3, 5, 8, 13, 21, 34]


/* ----------------------- Sample ---------------------------- */

func method1(num1:Int) -> Bool {
    guard num1 >= 2 else{ return false}
    for i in 2..<num1 {
        if num1 % i  == 0 {
            return false
        }
    }
    return true
}
