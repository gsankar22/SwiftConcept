//: [Previous](@previous)

import Foundation

/* Swift initializition */
/* Inilization is special type of function */
/* This is used to create an object of the class and Struct */
/* Parameterized Initializer - It can also accept one or more parameter */
/* Initializer overloading - Two or more initializer can have same name */
/* Convenience Initializer -  Inside the convenience we can call the designated initializer and assign the value */
/* failable initializer - Sometime it return nil which may or maynot work. Adding ? after init keywork */

class  initClass {
    var length: Double
    var width: Double
    //var folder: String
    
    
    init(){
        self.length = 20.0
        self.width = 10.0
    }
    
    // Parameterized initializer to initialize property
    init(length: Double, width: Double) {
        self.length = length
        self.width = width
        print("Length & Width = ", length + width)
    }
    
    /* convenience init(){
     self.init(length: 30.0 , width: 30.0)
     }*/
    
    /* Failable Initializer */
    /* init?(folder: String){
     if folder.isEmpty {
     print("Folder Not Found") // 1st output
     return nil
     }
     self.folder = folder
     } */
    
    func calculateArea() -> Double {
        return length + width
    }
}

// create an object
var wall1 = initClass(length: 55.0, width: 66.0  )
print("length - \(wall1.length)")
print("width - \(wall1.width)")
print("Area of Wall: ", wall1.calculateArea())

var wall2 = initClass()
print("wall2- length - \(wall2.length)")
print("wall2- width - \(wall2.width)")


var wall3 = initClass()
print("convenience init length:  \(wall3.length)")
print("convenience init width:  \(wall3.width)")

/*var file  = initClass(folder: "")
 if (file != nil) {
 print("File Found Successfully")
 }
 else {
 print("Error Finding File") // 2nd output
 }*/

/* Struct automatically generate the initializer */
struct empPerson {
    var name: String
    var age: Int
}

let structInilizer = empPerson(name: "Arjun", age: 5)
print("name: \(structInilizer.name)")
print("Age: \(structInilizer.age)")
