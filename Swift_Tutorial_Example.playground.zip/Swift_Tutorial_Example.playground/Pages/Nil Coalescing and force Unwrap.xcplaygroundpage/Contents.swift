//: [Previous](@previous)

import Foundation


struct allUser {
    let name: String
    let age: Int?
}

let myalluser = allUser(name: "Adithi", age: nil)


//IF LET

/*if age == myalluser.age ?? 0 {
 print("user age is \(age)")
 }else{
 print("user does not enter Age")
 }*/

//guard

func myage(age: Int?){
    guard let age else {
        print("age nill in guard")
        return
    }
    
    if age > 40{
        
        print("Age is greater than \(age)")
    }
    
}

myage(age: myalluser.age)

//Nil Coalescing

let age1 = myalluser.age ?? 0
print("Coalesing age- \(age1)")


//Force Unwrape'
/*let age2 = myalluser.age!
 print("Force - \(age2)")*/

//Optional Chaining

/*let optionalUser: allUser?
 
 let name = optionalUser?.name ?? "No Name"
 
 if let name = optionalUser?.name {
 print("it has age \(age)")
 }else{
 print("Age is nil")
 }*/

