//: [Previous](@previous)

import Foundation

struct Person {
    var name: String
    var age: Int
}


//class Person {
//    var name: String
//    var age: Int
//
//    init(name:String, age: Int) {
//        self.name = name
//        self.age = age
//
//    }
//}

// Shallow copy
var person1 = Person(name: "Alice", age: 30)
var person2 = person1 // Shallow copy
person2.age = 35

print(person1.age) // Output: 30 (because both person1 and person2 reference the same class instance)

// Deep copy
func deepCopy(person: Person) -> Person {
    return Person(name: person.name, age: person.age)
}

//var person3 = deepCopy(person: person1) // Deep copy
var person3 = person1 // Deep copy

person3.age = 40

print(person1.age) // Output: 35 (because modifying person3 doesn't affect person1)
print(person2.age)
print(person3.age) // Output: 40

