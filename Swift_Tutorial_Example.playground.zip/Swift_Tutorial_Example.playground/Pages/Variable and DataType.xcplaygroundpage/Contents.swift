//: [Previous](@previous)

import Foundation

/* Different Data types using variable */
var greeting: String = "Hello, playground"
var doublevalue: Double = 0.763453453
var floatvalue: Float = 0.7645452
print("Print String Value :",greeting)
print("Print Double value :",doublevalue)
print("Print float value : \(floatvalue)")

/**------------------------------------------------------------------------------------------------**/

/* Variables Declaration */
var myVariable : Int
myVariable = 100
print("Variable Declaration :",myVariable)

