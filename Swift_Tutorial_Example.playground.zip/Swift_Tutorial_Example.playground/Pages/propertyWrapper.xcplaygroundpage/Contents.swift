//: [Previous](@previous)

import Foundation


/* property wrapper */
/* Allows to custimize the behaviour of the properties */
/* Property wrappers are used to add custom behavior to stored properties.  */
/* Property wrappers are declared using the @propertyWrapper attribute and
 applied to properties using the @ symbol followed by the name of the wrapper. */

@propertyWrapper struct Trimmer {
    private var text: String
    var wrappedValue: String {
        get{
            text.trimmingCharacters(in: .whitespacesAndNewlines)
        }
        set{
            text = newValue
        }
    }
    
    init(myval: String) {
        text = myval
    }
    
}

@propertyWrapper
struct WrapperClass {
    private var value = ""
    
    var wrappedValue: String {
        get {
            value.uppercased()
            
        }
        set {
            value = newValue
            
        }
    }
}

struct Payload {
    @WrapperClass var text: String
    @Trimmer var trimmedText: String
}

var p = Payload(text: WrapperClass(), trimmedText: Trimmer(myval: "         Property Wrapper       "))
//var p = Payload(trimmedText: Trimmer(myval:  "         Property Wrapper       "))
p.text = "Hello Property Wrapper"
print(p.text)
print(p.trimmedText)

/*  ------------------------------------------------------------------- */

@propertyWrapper
struct sampelClass{
    private var value: Int = 0
    
    var wrappedValue: Int {
        get{
            value < 20 ? value: 100
        }
        set{
            print("new \(newValue) and old: \(value)")
            value = newValue
            
        }
    }
}

struct calss2{
    @sampelClass var myvalue: Int
}

var t = calss2()
t.myvalue = 19
print(t.myvalue)

/*  ------------------------------------------------------------------- */



/* Real time Example */

extension String {
    
    func isValidEmail() -> Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        
        let emailPred = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailPred.evaluate(with: self)
    }
}

@propertyWrapper
struct propwrapper{
    
    private var value: String
    
    var wrappedValue: String {
        
        get{
            return isValidEmail(email: value) ? value : String()
        }
        set{
            value = newValue
        }
    }
    
    init(emailvalue: String){
        value = emailvalue
    }
    
    func isValidEmail(email: String) -> Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        
        let emailPred = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailPred.evaluate(with: email)
    }
    
}

struct user{
    
    var name: String
    @propwrapper  var email: String
    
    func validate() -> Bool{
        if (name.isEmpty || email.isEmpty){
            print("Name and email Id is empty")
            return false
        }
        
        /* if (email.isValidEmail() == false){
         debugPrint("EmailID is invalid")
         return false
         }*/
        return true
    }
    
    func registerUser(){
        if (validate()){
            debugPrint("User Data Saved")
        }
    }
}

let use = user(name: "Gowri ", email: propwrapper(emailvalue: "gsankar22@gmailcom"))
use.registerUser()



