//: [Previous](@previous)

import Foundation

var greeting = "Hello, playground"

//: [Next](@next)

/* Array Example */
var ageempty : [Int] = []
var age = [21,55,19,78]
print("Array Count:",age.count)
print("Array index:",age[1])

age.append(99)
age.insert(45, at: 0)
age.sort()
age.reverse()



