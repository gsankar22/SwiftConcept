//: [Previous](@previous)

import Foundation


/* Static and Class function call */
/* Directly access the static and class function without object using class name */

class Person {
    
    // class let mycountry = "india" /* Class Stored Properties not supported in classes */
    
    var name: String
    static let desgination: String = "Technical Manager"
    class var mycountry : String {
        return "India"
    }
    
    init(Sname:String){
        self.name = Sname
    }
    
    func normalFunction(){
        print("normalFunction: Hello \(name)")
    }
    
    static func staticFunction(name : String) {
        print("staticFunction: \(name) Designation: \(desgination)" )
    }
    
    class func classFunction(value : String){
        print("classFunction: \(value) and country: \(mycountry)")
    }
}

/* Static and class Function instance not required */
Person.staticFunction(name: "Gowrisankar Samy")
Person.classFunction(value: "Kanimozhi")

/* Instance required to access normal function*/
let myclass = Person(Sname: "Gowri")
myclass.name = "Sankar"
myclass.normalFunction()

/*---------------------- Function Inheritance and Override  ------------------------------ */
/* function and class function can override but static function can not override */
class Man: Person {
    override func normalFunction() {
        print("Value is \(name)")
        
    }
    override class func classFunction(value: String) {
        print("classFunction Override: Hello \(value)")
    }
    // Can not override the static method
    /*
     static func staticFunction(name : String) {
     print("staticFunction Override: \(name) Designation: \(desgination)" )
     }
     */
}

let manoverride = Man(Sname: "Hello Man")
manoverride.normalFunction()

Man.classFunction(value: "Adithi")
