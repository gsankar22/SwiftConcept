import Foundation


/* ARC is used to manage the memory automatically */
/* It handles the Allocation and Deallocation of memory */
/* Keep tracking the number of reference count to each class instance
 And deallocate the instance when no longer needed */
/*
 1) Strong Regerence
 2) Weak reference
 3) Unowned
 */

/* --------------------  Strong Reference  -------------------------- */
/* Create the instance of classes [Reference count value incresed from 0 To 1]
 Deallocate the instance of classes [Reference count value decresed to 0] */
/* manually deallocate the memory using "NIL" but instance should be optional */

/* -------------------- Weak Reference ---------------------------------- */
/* Declare a property as Weak, The reference count of the property will never be more than 1 */
/* Weak var person:Person? = person() */

/* --------------------- Unowned ------------------------------------------- */
/* It does not incress the reference count & It will de deallocate easily */
/* particullary used to avoiding the retain cycle */
/*
 Unowned - If object is dependent with each other
 Weak  - If object is not depedent with each other
 */

/* --------------------      Example      -------------------------- */
/* --------------------  Strong Reference  -------------------------- */
class Bike {
    var color: String
    
    init(color: String) {
        self.color = color
    }
    deinit {
        print("\(color) - color is being deinitialized")
    }
}

var color_obj1:Bike? = Bike(color: "blue")
var color_obj2:Bike? = color_obj1
color_obj1?.color = "red"
print("Color1 - \(String(describing: color_obj1?.color))")
print("Color2 - \(String(describing: color_obj2?.color))")

color_obj1 = nil // Color is not deinilitiz because Obj2 still holds a Strong reference
color_obj2 = nil // Now deinilitiz because there are no moree Strong reference




/* -------------------- Weak Reference ---------------------------------- */
/* Declare a property as Weak, The reference count of the property will never be more than 1 */
/* Weak var person:Person? = person() */


class Person {
    var name: String
    var gender: Gender?
    init(name: String) {
        self.name = name
    }
    deinit {
        print("\(name) -  is being deinitialized")
    }
}

class Gender {
    weak var person:Person?
    var gendername: String
    
    init(gendername: String) {
        self.gendername = gendername
    }
    deinit {
        print("\(gendername) -  is being deinitialized")
    }
}

var person_obj:Person? = Person(name: "GowriSankar")
var gender_obj:Gender? = Gender(gendername: "Male")

person_obj?.gender = gender_obj
gender_obj?.person = person_obj

print("Name - \(String(describing: person_obj?.name))")
print("Gender - \(String(describing: gender_obj?.gendername))")

person_obj = nil // person is deinitialize because weak reference if gender doesnot  keep alive
gender_obj = nil // Gender also deinilize because there are no strong reference.


/* --------------------- Unowned ------------------------------------------- */
/* It does not incress the reference count & It will de deallocate easily */
/* particullary used to avoiding the retain cycle */
/*
 Unowned - If object is dependent with each other
 Weak  - If object is nt depedent with each other
 */


class Customer {
    var name: String
    var creditCard: CreditCard?
    init(name: String) {
        self.name = name
    }
    deinit {
        print("Customer \(name) -  is being deinitialized")
    }
}

class CreditCard {
    unowned var customer: Customer?
    var cardNumber: Int
    
    init(cardNumber: Int) {
        self.cardNumber = cardNumber
    }
    deinit {
        print("Card Number \(cardNumber) -  is being deinitialized")
    }
}

var customer_obj:Customer? = Customer(name: "GowriSankar")
var card_obj:CreditCard? = CreditCard(cardNumber: 1234_5678_1234_5678)

customer_obj?.creditCard = card_obj
//card_obj?.customer = customer_obj

print("Customer Name - \(String(describing: customer_obj?.name))")
print("Card Number - \(String(describing: card_obj?.cardNumber))")


customer_obj = nil
card_obj = nil
