//: [Previous](@previous)

import Foundation


/* POP - protocal oriented Programming */
/* It can support multiple protocal */
/* It can be used by class, Struct and enum */
/* It has protocal extension */
/* It has value type */

/* Swift Protocal */
/* Protocal is the blueprint of properties and method that can be adopted by the classes */
/* Use Protocal keyword to define the protocal */
/* Protocal property must have get or (get set) specifier */

/* Protocal is list of item that object has to follow */

/* ------------------- Protocal ------------------------------*/

protocol person {
    var name: String {get} // property declaration
    func Myfunction() // method declaration
}

class Callperson:person {
    var name: String = " "
    
    init(myName: String){
        name = myName
    }
    
    func Myfunction() {
        print("My name is \(name)")
    }
}

var personClass = Callperson(myName: "Adithi sankar")
personClass.Myfunction()

/* ------------------- Protocal (get set) Specifier------------------------------*/

protocol FullyNamed {
    var fullName: String { get set }
}
struct Detective: FullyNamed {
    var name: String
    var fullName: String {
        get {
            return name
        }
        set{
            name = newValue
        }
    }
}
var hercule = Detective(name: "AdiArjun")
print(hercule.fullName)
hercule.name = "Gowrisankar"
print(hercule.fullName)

/*  -------------------- Protocal Inheritance ---------------------------------------- */


/* Protocal Inheritance one or multiple Protocal */
/* Protocal can inherit other protocal or multiple protocal*/

protocol add {
    func addition()
}

protocol sub {
    func Suntraction()
}

protocol sum: add, sub {
    func multiple()
    func divide()
}

class CalculateClass: sum {
    
    
    var num1 = 0
    var num2 = 0
    
    func addition() {
        var number: Int
        number = num1 + num2
        print("Addition: \(number) ")
    }
    
    func Suntraction() {
        print("Subtraction: ",num1 - num2)
    }
    
    func multiple() {
        print("multiple: ",num1 * num2)
    }
    func divide() {
        print("multiple: ",num1 / num2)
    }
}

// create an object
var calculate = CalculateClass()

// assign values to properties
calculate.num1 = 10
calculate.num2 = 5

// access methods
calculate.addition()
calculate.Suntraction()
calculate.multiple()
calculate.divide()

/*  --------------------- Protocal Extension ---------------------------------------------- */

/* Protocal Extension */
/* Protocal can extend using "extension" keyword */
// protocol definition
protocol employeeDetails {
    
    func employeeName(name: String)
}

// define class that conforms Brake
class employee: employeeDetails {
    var age: Int = 0
    
    func employeeName(name: String) {
        print("Employee details: Name: \(name) & Age: ", age)
    }
    
}

// extend protocol
extension employeeDetails {
    var empID: Int {
        return 52029124
    }
    func employee_Designation() {
        print("Employee Designation is (Technical Arch) and id:\(empID)")
    }
}

let employee_obj = employee()
employee_obj.age = 39
print("Age:", employee_obj.age)
//employee_obj.empID = 52029124

employee_obj.employeeName(name:"Gowrisankar")
// access extended protocol
employee_obj.employee_Designation()

/*  ------------------------ Optional protocal ----------------------------------- */

/* Optional protocal */

/* Two way to call optional method */
/* Using (@objc & optional) and Anothe one is using extension */
/* @objc want swift code (class, method and propery) to be visible from Objective C*/

@objc protocol controller {
    func functionaA()
    @objc optional func functionaB()
    @objc optional func functionaC()
}

class optionalClass : controller {
    func functionaA() {
        print("Function A")
        print("B and C is Optional method")
    }
    /* func functionaB() {
     print("Function B")
     } */
}


// Another way optional protocal
/* Extension both protocal and class */

/*extension controller {
 func functionaB(){}
 func functionaC(){}
 }*/

extension optionalClass {
    func functionaB() {
        print("functiona B")
    }
}


let protocal_obj = optionalClass()
protocal_obj.functionaA()
protocal_obj.functionaB()
