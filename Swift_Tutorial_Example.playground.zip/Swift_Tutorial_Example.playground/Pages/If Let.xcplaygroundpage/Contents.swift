//: [Previous](@previous)

import Foundation


var myText : String?
//myText = "Gowrisankar"

//print(myText)

if let value = myText{
    print("If Let statument : \(value)")
}


func printValue (){
    guard let value = myText else {
        var fName:String
        fName = "Samy"
        print("First value : \(fName)")
        return
    }
    
    print("inside value : \(value)")
}


printValue()
