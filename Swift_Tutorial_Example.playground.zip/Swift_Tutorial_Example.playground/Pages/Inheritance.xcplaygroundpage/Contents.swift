//: [Previous](@previous)

import Foundation

/* Swift Inheritance */
/* Create the new class from the existing class */
/* Subclass access the method of super class */
/* Overriding Inheritance - subclass can overriding the method of supercalss */
/* Super keyword -  need to acess the superclass method from subclass using super Keyword*/

class InhertanceClass_A {
    var name: String = ""
    func eat() {
        print("I can eat")
    }
}

class InhertanceClass_B: InhertanceClass_A {
    func display() {
        // access name property of superclass
        print("My love to eat ", name);
    }
    
    override func eat() {
        super.eat() // acess the superclass method from subclass
        print("I can eat override")
    }
}

var labrador = InhertanceClass_B()
// access superclass property and method
labrador.name = "pizza"
labrador.eat()
// call subclass method
labrador.display()

/* -------------------------------------------------- */

/* Prevent method Overriding using final keyword */
/* method non overriding we can add the final keyword in super class method */
/* Class decelare as final cannot be create the subclass */

class finalClass_A {
    var name: String = ""
    final func eat() {
        print("I can eat")
    }
    
    static func cook(){
        print("Piza")
    }
    
    func mycook(){
        print("Mycook")
    }
}

class finalClass_B: finalClass_A {
    //error cannot overeide the mathod declared as final
    /* override func eat() {
     print("overriding")
     }*/
    
    //error cannot overeide the mathod declared as static
    /* override func cook(){
     print("overriding")
     } */
    override func mycook() {
        print("Can able to override")
    }
}

let finalClass = finalClass_B()
finalClass.mycook()
