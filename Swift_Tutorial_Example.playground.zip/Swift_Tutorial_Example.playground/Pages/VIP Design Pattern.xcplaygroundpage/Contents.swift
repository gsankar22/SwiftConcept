//: [Previous](@previous)

import Foundation
import UIKit



// User Model
struct User {
    let id: Int
    let name: String
}

// View Protocol
protocol UserListView: AnyObject {
    func displayUsers(_ users: [User])
}

// Interactor
class UserListInteractor {
    func fetchUsers() -> [User] {
        // Mock data source
        return [
            User(id: 1, name: "John"),
            User(id: 2, name: "Alice"),
            User(id: 3, name: "Bob")
        ]
    }
}

// Presenter
class UserListPresenter {
    weak var view: UserListView?
    var interactor: UserListInteractor!
    
    func viewDidLoad() {
        let users = interactor.fetchUsers()
        view?.displayUsers(users)
    }
}

// View Controller
class ViewController: UIViewController , UserListView {
    
    var presenter: UserListPresenter!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        presenter = UserListPresenter()
        presenter.view = self
        presenter.interactor = UserListInteractor()
        presenter.viewDidLoad()
    }
    
    func displayUsers(_ users: [User]) {
        for user in users {
            print("User ID: \(user.id), Name: \(user.name)")
        }
    }
}

// Usage
let viewController = ViewController()


