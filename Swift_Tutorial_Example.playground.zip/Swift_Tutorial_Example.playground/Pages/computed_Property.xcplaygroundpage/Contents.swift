//: [Previous](@previous)

import Foundation

/* computed property */
/* Allows to customize the behaviour of the properties */
/* Computed properties are used to calculate a value dynamically. They don't store a value directly */
/* Computed properties are declared using the var keyword, and they provide a getter (and optionally a setter) to compute the value. */




//Example1
class StoredComputed{
    
    //Stored property
    var num1: Int = 0
    var num2: Int = 0
    
    //computed property
    var sum: Int {
        get{
            num1 + num2
        }
        set(num3){
            num1 = (num3 + 10)
            num2 = (num3 + 20)
        }
    }
}

let myComputedProperty = StoredComputed()
myComputedProperty.num1 = 20
myComputedProperty.num2 = 30
print("StoredProperty - \(myComputedProperty.sum)")
myComputedProperty.sum = 5
print("ComputedProperty Number1 - \(myComputedProperty.num1)")
print("ComputedProperty Number2 - \(myComputedProperty.num2)")

/*  ---------------------------- Example  --------------------------------------- */

struct studentresult {
    
    //Stored property
    let  studentName : String
    let studentResult : Int
    
    // optional properties
    lazy var id: Int? = 0
    
    //computed property
    var mystudentResult : Bool {
        return studentResult > 40
    }
}

var myresult = studentresult(studentName: "Adithi", studentResult: 50)
print("Student detials - \(myresult.studentName) and \(myresult.studentResult) and id is \( myresult.id ?? 0)")

print(myresult.mystudentResult)

/*  ------------------------------------------------------------------- */
