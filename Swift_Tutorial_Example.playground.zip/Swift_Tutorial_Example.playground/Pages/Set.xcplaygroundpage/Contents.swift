//: [Previous](@previous)

import Foundation

var greeting = "Hello, playground"

/* Set Example */
var ageSet : Set<Int> = []

var ages = [26,99,78,17,65,54,99,26]
var newAge = Set(ages)
print("Set:",newAge)


/* Hashable Example */
newAge.contains(17)
newAge.insert(101)
print (newAge)


