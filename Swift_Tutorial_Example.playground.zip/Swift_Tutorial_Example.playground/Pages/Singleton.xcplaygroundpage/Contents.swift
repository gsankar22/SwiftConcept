//: [Previous](@previous)

import Foundation

/* Singleton  and static singleton object */
/* Class can have only one object such class is called singleton class */
/* It has global access throught out the code base */
/* private initializer -  It helps to restrict the object creation of class from the outside of the class */

class MySingleton {
    // Static constant instance property
    static let sharedInstance = MySingleton()
    
    var name: String = {
        return ""
    }()
    
    // Private initializer to prevent outside instantiation
    private init() {
        // Initialization code here
    }
    
    // Example method
    func doSomething() {
        print("Singleton is doing something",name)
    }
}

// Usage
MySingleton.sharedInstance.name = "Sankar"
MySingleton.sharedInstance.doSomething()
