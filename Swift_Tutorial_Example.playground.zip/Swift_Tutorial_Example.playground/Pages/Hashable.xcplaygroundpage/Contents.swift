//: [Previous](@previous)

import Foundation


/* Hashable protocal */
/* Hashable is protocal that provides hash value for the object */
/* hashvalue used to compair  two objects */

struct Employee: Hashable {
    var name: String
}

let object1 = Employee(name: "Sabby")
let object2 = Employee(name: "Smith")

// print hash values
print(object1.hashValue)
print(object2.hashValue)

/* hash function */
/* Hash function help to compair the selective property of the type */

func hash(into hasher: inout Hasher) {
    //hasher.combine(salary)
}

