//: [Previous](@previous)

import Foundation
import UIKit

/* Modelis the data layer and it represent the actual data that contains the basic information */

// Model
struct Person {
    let name: String
    let age: Int
}

/* ViewModel is the bridge between the model and View. */

// ViewModel
class PersonViewModel {
    
    private let person: Person
    
    init(person: Person) {
        self.person = person
    }
    
    var name: String {
        return person.name
    }
    
    var age: String {
        return "Age: \(person.age)"
    }
}

// View
/* It is the user interaction layer and display the data on the screen */

class PersonViewController: UIViewController {
    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var ageLabel: UILabel!
    
    var personViewModel: PersonViewModel! {
        didSet {
            updateView()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        updateView()
    }
    
    private func updateView() {
        guard isViewLoaded else { return }
        nameLabel.text = personViewModel.name
        ageLabel.text = personViewModel.age
    }
}

// Usage
let person = Person(name: "John Doe", age: 30)
let personViewModel = PersonViewModel(person: person)

let storyboard = UIStoryboard(name: "Main", bundle: nil)
let viewController = storyboard.instantiateViewController(withIdentifier: "PersonViewController") as! PersonViewController
viewController.personViewModel = personViewModel
