//: [Previous](@previous)

import Foundation


/* Struct & Class different and Example*/
/* Class and struct is general purpose and it helps to build the block of programming code */
/* use the same syntex for variable, constant and function */
/* Both struct and class use in same swift file */



/* Struct is the value type and memory allocated in stack */
/* Each instance of Struct can have individual copy of data */

/* ------------------------- Struct --------------------------- */
struct bike {
    var color: String
    init(color: String) {
        self.color = color
    }
}

var color_obj1 = bike(color: "blue")
var color_obj2 = color_obj1
color_obj1.color = "red"
print("Color1 - \(color_obj1.color)")
print("Color2 - \(color_obj2.color)")



/* ---------------------- Struc Extension --------------------- */
extension bike {
    var name: String {
        return "Pulser"
    }
}

var color_obj3 = bike(color: "Yellow")
print("Color3 - \(color_obj3.color)")
print("Bike name - \(color_obj3.name)")







