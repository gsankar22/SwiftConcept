//: [Previous](@previous)

import Foundation


/* Generic Function and Class */
/* Generic Class - Create a class that can be used with anytype of data */
/* Generic function - Create a function that can be used with anytype of data */
/* Create generic function or class using  T used in angle bracket <> */

// create a generic class
class genericClass<T> {
    
    // property of T type
    var data: T
    
    init (data: T) {
        self.data = data
    }
    
    // method that return T type variable
    func genericFunction() -> T {
        return self.data
    }
}

// initialize generic class with Int data
var intObj = genericClass<Int>(data: 6)
print("Generic Class returns:", intObj.genericFunction())

// initialize generic class with String data
var strObj = genericClass<String>(data: "Swift")
print("Generic Class returns:", strObj.genericFunction())

/* Type Constrain using generic */

//create a generic function with type constraint
func addition<T: Numeric>(num1: T, num2: T) {
    
    print("Sum:", num1 + num2)
}

// pass Int value
addition(num1: 5, num2: 10)

// pass Double value
addition(num1: 5.5, num2: 10.8)


//Generic function Example

func highervalue<T: Comparable>(valueone: T, valuetwo: T){
    let compairValue = valueone > valuetwo ? valueone : valuetwo
    print("The higher value is \(compairValue)")
}

highervalue(valueone: 8, valuetwo: 10)
highervalue(valueone: "gowri", valuetwo: "kani")
