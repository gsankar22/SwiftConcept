//: [Previous](@previous)

import Foundation

/* Different Data types using variable */
let greeting: String = "Hello, playground"
let doublevalue: Double = 0.763453453
let floatvalue: Float = 0.7645452
print("Print String Value :",greeting)
print("Print Double value :",doublevalue)
print("Print float value : \(floatvalue)")

/* ConstantDeclaration */
let highscore : Int
highscore = 10
print("Constrant Declaration :",highscore)
