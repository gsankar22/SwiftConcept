//: [Previous](@previous)

import Foundation

let serialQueue = DispatchQueue(label: "com.example.serialQueue")

serialQueue.async {
    print("Task 1")
    Thread.sleep(forTimeInterval:2)
    
}

serialQueue.async {
    print("Task 2")
}

serialQueue.async {
    print("Task 3")
}



/* ----------------------------------------*/

let concurrentQueue = DispatchQueue(label: "com.example.concurrentQueue", attributes: .concurrent)

concurrentQueue.async {
    print("Task 1")
}

concurrentQueue.async {
    print("Task 2")
}

concurrentQueue.async {
    print("Task 3")
}


