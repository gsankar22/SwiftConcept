//: [Previous](@previous)

import Foundation

/**  Completion handler @nonescaping and @escaping */
/* A completion handler is a closure or a callback function that gets called after a task has been completed. */
/* it is commonly used in asynchronous programming to handle the result of an operation once it finishes. */

//@nonescaping

class ServerCall {
    
    
    func sample(){
        print("Step1")
        samplecall(num1: 10, num2: 20){ [weak self] (result) in
            guard let _ = self else {return}
            print("Result is : \(result)")
            
        }
        print("LastStep")
    }
    
    func samplecall(num1: Int, num2 : Int , completionHandler: (_ result : Int) -> Void){
        print("Step2")
        let result = num1 + num2
        
        
        //@nonescaping
        print("Step3")
        completionHandler(result)
        
        //@escaping
        /*DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 0.3) {
         print("Step3")
         completionHandler(result)
         }*/
        print("Step4")
    }
}


let mycall = ServerCall()
mycall.sample()

/* -------------------------------------------------------------------- */
//Example2


//Gobal

var globalCompletion: () -> Void = {}

func datacall(_name: String, completionHandler: @escaping () -> Void){
    globalCompletion = completionHandler
}

//Asynchronous operation

class Server {
    
    class func datacall(_name: String, compHandler: @escaping (String) -> Void){
        
        DispatchQueue.global(qos: .background).async {
            DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 0.03) {
                compHandler(_name)
            }
        }
    }
}

Server.datacall(_name: "Gowri") { (result) in
    print("value : \(result)")
    
}



class Myuser : ObservableObject {
    var name: String
    var jobTitle :String
    var jobCount : Int
    var bio : String
    
    init(name: String, jobtitle : String, jobCount : Int, bio : String){
        self.name = name
        self.jobTitle = jobtitle
        self.jobCount = jobCount
        self.bio = bio
        
    }
    
}
/* ------------------------------------------------------- */

// Function to simulate a network request
func fetchData(completion: @escaping (Result<String, Error>) -> Void) {
    // Simulating a network request that takes some time
    DispatchQueue.global().async {
        // Simulate success or failure randomly
        let isSuccess = Bool.random()
        if isSuccess {
            // If successful, return some data
            completion(.success("Data fetched successfully"))
        } else {
            // If failed, return an error
            completion(.failure(NSError(domain: "com.example", code: 500, userInfo: [NSLocalizedDescriptionKey: "Failed to fetch data"])))
        }
    }
}

// Example usage of the fetchData function with a completion handler
fetchData { result in
    switch result {
    case .success(let data):
        print("Success: \(data)")
    case .failure(let error):
        print("Error: \(error.localizedDescription)")
    }
}

