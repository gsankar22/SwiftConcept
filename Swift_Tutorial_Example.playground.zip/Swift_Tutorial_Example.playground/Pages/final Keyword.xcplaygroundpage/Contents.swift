//: [Previous](@previous)

import Foundation

/* Prevent method Overriding using final keyword */
/* method non overriding we can add the final keyword in super class method */
/* Class decelare as final cannot be create the subclass */

class finalClass_A {
    var name: String = ""
    final func eat() {
        print("I can eat")
    }
}

class finalClass_B: finalClass_A {
    //error cannot overeide the mathod declared as final
    /* override func eat() {
     print("overriding")
     }*/
}

let finalClass = finalClass_B()
finalClass.eat()
