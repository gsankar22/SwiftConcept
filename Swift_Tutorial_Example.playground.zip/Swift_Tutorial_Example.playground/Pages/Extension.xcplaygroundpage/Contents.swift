//: [Previous](@previous)

import Foundation


/* Swift Extensio */
/* Add the new functionality to the existing type [Class & protocal] */
/* Extension keyword to use the classes, struct and protocal */
/* Cannot add the stored property in extension class */

/* Class*/
class myExtension {
    var radius: Double = 0
}


extension myExtension {
    //  Can not add stored property
    /* var area: Double  // error code */
    
    // computed property
    var area: Double {
        return 3.14 * radius * radius
    }
}

let circle1 = myExtension()
circle1.radius = 5
print("Area:", circle1.area)

/*----------------------------- Struct ----------------------------------------------- */
struct  StructExtension{
    var num1:Int
    var num2:Int
}


extension StructExtension{
    
    var num3: Int {
        get
        {
            num1 + num2
        }
        set
        {
            num3 = newValue
        }
    }
    
    
    func myFunction() -> Int{
        return num3
    }
    
}

var myStruct = StructExtension(num1: 25, num2: 25)
debugPrint("Struct value: \(myStruct.myFunction())")


/* ----------------------------- protocal ----------------------------------------*/

protocol carProtocal{
    var carColor: String { get }
}

class car: carProtocal {
    var carColor: String
    
    init(cars: String){
        carColor = cars
    }
    
    func carDetails(){
        print("My Car color - \(carColor)")
    }
    
    
    
}

extension carProtocal{
    var carModel: String {
        return "Ford Figo 2010"
    }
    func FunctionA(){}
    
}

extension car {
    func FunctionA(){
        debugPrint("Protocal Extension Function & model \(carModel)")
    }
}

var car_obj = car(cars: "Blue")
car_obj.carDetails()
car_obj.FunctionA()


