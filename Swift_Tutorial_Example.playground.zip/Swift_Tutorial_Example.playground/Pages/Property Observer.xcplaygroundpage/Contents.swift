//: [Previous](@previous)

import Foundation

/* property Observer Example */
/* It has willset and didset method */
/* Both method are called everytime a property value is set */
/* Willset will called just before value is stored */
/* didset will called immediately after newvalue is stored */

var safeNumber: Int = 0 {
    willSet {
        if newValue < 0 {
            print("Invalid value, setting to 0.")
            safeNumber = 0
        } else if newValue > 10 {
            print("Value too high, setting to 10.")
            safeNumber = 10
        }
    }
    didSet {
        print("Number set from \(oldValue) to \(safeNumber)")
    }
}
//safeNumber = 12  // Outputs: Invalid value, setting to 0. Number set to 0.
safeNumber = -1

var myNumber: Int = 1 {
    willSet(newNumber) {
        print("About to change to \(newNumber)")
        
    }
    didSet
    {
        debugPrint("The oldValue: \(oldValue) and new value: \(myNumber + 10)")
    }
}
myNumber = 5


//var myNumber: Int = 1 {
//    didSet {
//        print("Just changed from \(oldValue) to \(myNumber)")
//
//    }
//}
//myNumber = 5

struct Student {
    var firstName: String {
        didSet {
            firstName = firstName.uppercased()
        }
    }
    var lastName: String {
        didSet {
            lastName = lastName.uppercased()
        }
    }
    init(firstName: String, lastName: String) {
        self.firstName = firstName.uppercased()
        self.lastName = lastName.uppercased()
    }
}

print( "the name is \(Student(firstName: "Arjun", lastName: "Sankar"))")


