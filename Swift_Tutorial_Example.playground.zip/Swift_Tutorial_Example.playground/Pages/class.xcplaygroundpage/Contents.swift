//: [Previous](@previous)

import Foundation

/* Struct and Class difference */

/* Struct & Class different and Example*/
/* Class and struct is general purpose and it helps to build the block of programming code */
/* use the same syntex for variable, constant and function */
/* Both struct and class use in same swift file */

/* Class */

/* Class is the reference type and memory allocated in heap */
/* Each instance of class can have same copy of data */
/* Class can inherite from another class */
/* Class can be deinilized deinit() before it destoryed */

/* --------------------------  Class ---------------------------- */
class Bike {
    var color: String
    init(color: String) {
        self.color = color
    }
    func bikeFunction(){
        print("Super Class Bike color - \(color)")
    }
}

var color_obj1 = Bike(color: "blue")
var color_obj2 = color_obj1
color_obj1.color = "red"
print("Color1 - \(color_obj1.color)")
print("Color2 - \(color_obj2.color)")
color_obj1.bikeFunction()



/* -----------------------  Class inheritance ------------------------- */
class car: Bike {
    
    override func bikeFunction() {
        super.bikeFunction()
        print("Sub Class Bike color - \(color)")
    }
}

var car_obj = car(color: "Rose")
car_obj.bikeFunction()


