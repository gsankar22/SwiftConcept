//: [Previous](@previous)

import Foundation


// Higher Order function


/* A function that operates on other function by taking them as Argument / Parameter or return function */


struct IndiaApp{
    
    let name: String
    let monthlyPrice: Double
    let users: Int
}

/*let appprofile = [IndiaApp(name: "gowri", monthlyPrice: 11.99, users: 678),
 IndiaApp(name: "kani", monthlyPrice: 19.99, users: 222),
 IndiaApp(name: "Adithi", monthlyPrice: 5.99, users: 567),
 IndiaApp(name: "Arjun", monthlyPrice: 02.99, users: 123),
 IndiaApp(name: "Samy", monthlyPrice: 22.00, users: 378)]*/

//let mapNames = appprofile.map { $0.name}.sorted()
//print("the mapNames is \(mapNames)")






/* --------------------  map -------------------------------------------- */
/* Creating new Array by append closure to the each element */

let mapNumber = [1,2,3,4,5]
let mapNum = mapNumber.map {
    $0 * 2
}
print("Map Value is \(mapNum)")


/* --------------------  compactMap -------------------------------------------- */
/* It is similar to map but It also remove the nil value from the new array */

let nilNumber = [3,nil,4,7,5,nil,10]
let compactNumber = nilNumber.compactMap { $0 }
print("compactMap value -- \(compactNumber)")



/* --------------------  flatMap -------------------------------------------- */
/* Collection inside the collection */
/* It merge the collection into the single collection */

let arrayOfArray = [[1,2,3],[4,5,6],[7,8,9]]
let arrayFlat  = arrayOfArray.flatMap { $0 }
print("FlatMap Value - >",arrayFlat)



/* --------------------  Filter -------------------------------------------- */
/* Create the new array based on the condition */

let ArrFilter = [1,2,3,4,5]
let newArrFilter = ArrFilter.filter{ $0 * 2 > 5}
print("Filter value is \(newArrFilter)")


/* --------------------  reduce -------------------------------------------- */
/* Combain all the element into the single Value */

let newnumber = [1,2,3,4,5]
let myReduce = newnumber.reduce (10, +)
print("My Reducer : \(myReduce)")


/*let reduceAnother = appprofile.reduce(0, {$0 + $1.users})
 print("Reduce - \(myReduce)")
 
 
 let requirreven = appprofile.map { $0.monthlyPrice * Double($0.users)}.reduce(0,+)
 print("requirreven - \(requirreven)")*/


/* --------------------  forEach -------------------------------------------- */
/* perform a action on each element */
/* ForEach does not reture new array or collection */

let forprint = [1,2,3,4,5]

forprint.forEach{ num in
    print("ForEach value: \(num)")
}



/* --------------------  contains -------------------------------------------- */
/* It is used to check whether a collection contains specific elements */
/* It returns boolean value */

let containval1 = [1,2,3,4,5]
if containval1.contains(3){
    print("it is available")
} else {
    debugPrint("it is not available")
}

