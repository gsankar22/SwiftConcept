//: [Previous](@previous)

import Foundation

/*  Gaurd Let Example */

func  numberCheck(number: Int) -> Bool {
    
    guard number > 5 , number > 4 else {
        return false
    }
    return true
}

numberCheck(number: 4)


var myText : String?
//myText = "Gowrisankar"

//print(myText)
