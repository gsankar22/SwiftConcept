//: [Previous](@previous)

import Foundation


/* ------------------ Solid principle ---------------------------*/

/* SOLID represent the 5 principle in Object Oriented Programing or Design */
/*
 1) Single responsibility Principle
 2) Open/Closed Principle
 3) Likov Substitution Principle
 4) Interface Segregation priniple
 5) Depedency Inversion principle
 */

/* ------------------- Single Responsibility Principle ----------------- */
/* SRP Principle Each module or classes shoul have only one responsiblility and reason to change */
/* Class or object should have one perpose and used only for one thing */

/* Network class perform multiple resposbility */
/*
 Making networkcall
 Parsing the response
 Saving the data
 */

/* --------------- Example Without SPR --------------------- */
class NetworkManager {
    func networkCall(data: String) {
        // Code to network request
    }
    
    func SaveToDatabase(data: String) {
        // Code to save data to a database
    }
}

/* --------------- Example With SPR --------------------- */
/* To solve this problem Seperate the responsibility to Little classes*/

class NetworkCall {
    func networkCall(data: String) {
        // Code to network request
    }
}

class DatabaseCall {
    func SaveToDatabase(data: String) {
        // Code to save data to a database
    }
}

/* ------------------- OPEN / CLOSED Principle ----------------- */
/*
 
 1) IN software entity [Classes, Function & Modules] should be open for extension
 but closed for modification
 
 2) Use Override and extension for adding new functionality without changing the
 implementation in the existing source code
 
 */

/*---------------------- Example with Override & Extension  ------------------------------ */
//BaseClass
class Employee {
    func employeeName(){
        print("Employee name is Gowri")
    }
}

//SubClass
class Employer: Employee {
    override func employeeName() {
        print("Employer name is Sankar")
    }
}

extension Employee {
    @objc func employeeNumber(){
        print("Employee ID 12345")
    }
}

extension Employer {
    override func employeeNumber() {
        print("Employer new ID is 6789012")
    }
}


/* ------------------- Liskov Substitution Principle ----------------- */

/* subclasses must be able to use the object of their superclass without changing its behavior. */

// Superclass
class Bird {
    func fly() {
        print("Flying")
    }
}

// Subclasses
class Sparrow: Bird {
    // Sparrows can fly
}

// Function using Bird objects
func makeBirdFly(bird: Bird) {
    bird.fly()
}

let sparrow = Sparrow()
makeBirdFly(bird: sparrow)


/* ------------------- Interface Segragation Principle ----------------- */

/* Instead of one big interface, many small interface are preffered based of the group of method */

//Big Interface
protocol Document {
    func open()
    func save()
    func close()
}

//Small Interface
protocol Openable {
    func open()
}
protocol Saveable {
    func save()
}
protocol closable {
    func close()
}

class readDocument: Openable, closable {
    func open() {
        // Open Code
    }
    
    func close() {
        // Close Code
    }
}

/* ------------------- Depedency Inversion Principle ----------------- */
/*
 High-level modules should not depend on low-level modules but both should depend on abstractions.
 Abstractions should not depend on details but details should depend on abstractions.
 */


// Protocol defining the interface for a data source abstractions
protocol DataSource {
    func fetchData() -> String
}

// High-level module depending on DataSource abstraction
class DataManager {
    let dataSource: DataSource
    
    init(dataSource: DataSource) {
        self.dataSource = dataSource
    }
    
    func processData() {
        let data = dataSource.fetchData()
        print("Processing data: \(data)")
    }
}

// Low-level module implementing DataSource
class LocalDataSource: DataSource {
    func fetchData() -> String {
        return "Data from local source"
    }
}

class RemoteDataSource: DataSource {
    func fetchData() -> String {
        return "Data from remote source"
    }
}

// Usage
let localDataSource = LocalDataSource()
let remoteDataSource = RemoteDataSource()

let localDataManager = DataManager(dataSource: localDataSource)
localDataManager.processData() // Output: Processing data: Data from local source

let remoteDataManager = DataManager(dataSource: remoteDataSource)
remoteDataManager.processData() // Output: Processing data: Data from remote source
