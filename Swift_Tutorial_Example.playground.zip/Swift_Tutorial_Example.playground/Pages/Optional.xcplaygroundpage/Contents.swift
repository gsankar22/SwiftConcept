//: [Previous](@previous)

import Foundation


/* Optional Example */

let number: Int? = Optional.some(42)
let noNumber: Int? = Optional.none
print(noNumber == nil)

let imagePaths = ["star": "/glyphs/star.png",
                  "portrait": "/images/content/portrait.jpg",
                  "spacer": "/images/shared/spacer.gif"]

//optional Binding
/* Optional Binding Control statement - If let, Guard Let and Switch */



if let starPath = imagePaths["star"] {
    print("The star image is at '\(starPath)'")
} else {
    print("Couldn't find the star image")
}

//Optional chaining (?)
/*To access the method of wrapped instance using Profix(?) */

if imagePaths["star"]?.hasSuffix(".png") == true {
    print("The star image is in PNG format")
}

//Nil- coalescing operaor

let defaultImagePath = "/images/default.png"
let heartPath = imagePaths["heart"] ?? defaultImagePath
print(heartPath)


//Unconditional and unwrapped

let number11 = Int(42)
print(number11)

