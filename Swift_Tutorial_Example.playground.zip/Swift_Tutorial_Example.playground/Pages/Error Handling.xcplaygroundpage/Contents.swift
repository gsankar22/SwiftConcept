//: [Previous](@previous)

import Foundation


/* Error Handeling */
/* Error or exception is unexpected event occurs during the programming execution*/
/* Throw Keyword - create throw function using throw keyword */
/* try keyword - calling throw function using try keyword */
/* Do-Catch Statement - try code in do block and add the catch to handle all error */

var numerator = 0
var denominator = 0

// try to divide a number by 0
//var myres = numerator / denominator // error code


enum DivisionError: Error {
    case dividedByZero
}

// create throwing function using throws keyword
func division(numerator: Int, denominator: Int) throws -> Int{
    
    var myres: Int
    // throw error if divide by 0
    if denominator == 0 {
        throw DivisionError.dividedByZero
    }else{
        myres = numerator / denominator
    }
    print("Value",myres)
    return myres
}

// call throwing function using try keyword
do {
    try division(numerator: 10, denominator: 0)
}
catch DivisionError.dividedByZero {
    print("Error return")
}

