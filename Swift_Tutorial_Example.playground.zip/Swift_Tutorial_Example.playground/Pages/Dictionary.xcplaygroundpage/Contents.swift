//: [Previous](@previous)

import Foundation

/* Dictionary  Example */
//Key //Value pair

let newdevice : [String:String] = [:]
let device : [String:String] = ["iphoen" : "iphone x",
                                "laptop" : "2016 macBook Pro",
                                "Tablet" : "Samsung Tablet New"]

print("Dictionary Value:",device["laptop"] ?? "Not available")
