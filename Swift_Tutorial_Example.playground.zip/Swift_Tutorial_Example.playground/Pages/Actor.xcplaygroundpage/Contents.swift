//: [Previous](@previous)

import Foundation

/* Actor Example 1  */

actor userStorage{
    private var store = [String: User] ()
    
    func get(_ id:String) -> User? {
        return store[id]
    }
    
    func save(_user: User){
        store[user.id] = user
    }
    
    init(){
        
    }
    
}

class User {
    let id: String
    let name: String
    
    init(id:String, name: String){
        self.id = id
        self.name = name
    }
}

let user = User(id: "123", name: "Gowri")
Task{
    let storgae = userStorage()
    await storgae.save(_user: user)
    let get = await storgae.get("456")
    print(String(describing: get))
}

/* Actor Example 2 */

actor Account {
    var balance: Int = 20// current user balance is 20
    // ...
    func withdraw(amount: Int) {
        guard balance >= amount else {return}
        self.balance = balance - amount
    }
}

actor TransactionManager {
    let account: Account
    
    init(account: Account) {
        self.account = account
    }
    
    func performWithdrawal(amount: Int) async {
        await account.withdraw(amount: amount)
    }
}

// Usage
let account = Account()
let manager = TransactionManager(account: account)

// Perform a withdrawal from TransactionManager Actor
Task {
    // cross-actor reference
    await manager.performWithdrawal(amount: 10)
}

// Perform a withdrawal from outside any actor
Task {
    // cross-actor reference
    await account.withdraw(amount: 5)
}

func calculateSum(values: [Int], completion: ((Int) -> Void)) {
    // Step 2: Do some additional work with function.
    var sum:Int = 0
    for value in values {
        sum += value
    }
    // Step 3: Function runs the closure.
    completion(sum)
}

// Step 1: Pass the closure as function argument, during the function call.
calculateSum(values: [23,54, 45, 15, 38]) { sum in
    // Step 4: Function returns the compiler back and finished execution
    print(sum)
}


